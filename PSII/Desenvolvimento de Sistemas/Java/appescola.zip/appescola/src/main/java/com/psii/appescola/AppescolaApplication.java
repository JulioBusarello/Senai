package com.psii.appescola;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppescolaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppescolaApplication.class, args);
	}

}
