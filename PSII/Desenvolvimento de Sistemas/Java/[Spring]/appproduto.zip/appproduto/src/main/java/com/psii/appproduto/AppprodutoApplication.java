package com.psii.appproduto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppprodutoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppprodutoApplication.class, args);
		
	}

}
