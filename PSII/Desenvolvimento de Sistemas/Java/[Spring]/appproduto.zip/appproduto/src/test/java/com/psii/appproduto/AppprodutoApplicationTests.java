package com.psii.appproduto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppprodutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
