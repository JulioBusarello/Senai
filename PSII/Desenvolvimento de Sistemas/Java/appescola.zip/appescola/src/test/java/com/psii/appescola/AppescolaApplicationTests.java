package com.psii.appescola;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppescolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
